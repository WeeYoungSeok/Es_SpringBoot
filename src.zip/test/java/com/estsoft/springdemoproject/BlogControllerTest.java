package com.estsoft.springdemoproject;

import com.estsoft.springdemoproject.blog.domain.UpdateArticleRequest;
import com.estsoft.springdemoproject.blog.service.BlogService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;

@SpringBootTest
@AutoConfigureMockMvc
public class BlogControllerTest {

    @Autowired
    private ObjectMapper objectMapper;
    @Autowired
    private MockMvc mockMvc;
    @Autowired
    private WebApplicationContext context;
    @Autowired
    private BlogService blogService;


    @BeforeEach
    public void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(context).build();
    }

    @Test
    public void updateArticleException() throws Exception {
        // given : id, requestBody
        // my code
//        UpdateArticleRequest request = new UpdateArticleRequest("테스트 변경 제목", "테스트 변경 내용");
//        String updateJasonContent = objectMapper.writeValueAsString(request);

         Long notExistId = 3L;
         UpdateArticleRequest request = UpdateArticleRequest.builder()
                 .title("테스트 변경 제목")
                 .content("테스트 변경 내용")
                 .build();
         // 직렬화
         String requestBody = objectMapper.writeValueAsString(request);

        // when : 수정 API 호출 (/article/{id}, requestBody)
        ResultActions resultActions = mockMvc.perform(put("/articles/{id}", notExistId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestBody)
        );

        // then : 400 Bad Request
        resultActions.andExpect(status().isBadRequest());
        // 예외 검증 (발생할 예외, 메소드에서 예외 발생시켰을 때 나오는 예외) 같아야 넘어감
        assertThrows(IllegalArgumentException.class, () -> blogService.updateArticle(notExistId, request));
    }
}
