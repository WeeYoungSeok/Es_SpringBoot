package com.estsoft.springdemoproject.lombok;


import java.util.List;

public class LombokTest {
    public static void main(String[] args) {
        People people = new People(1L, "위영석", 23, List.of("게임", "볼링"));
        System.out.println(people.getHobbies());
        people.setHobbies(List.of("하이루"));
        System.out.println(people.getHobbies());

        People people1 = new People(2L, "Required 생성자 호");
    }
}
