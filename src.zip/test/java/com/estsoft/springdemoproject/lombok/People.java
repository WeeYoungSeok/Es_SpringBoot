package com.estsoft.springdemoproject.lombok;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

import java.util.List;

@AllArgsConstructor // 모든 피드를 파라미터로 가지는 생성자
@RequiredArgsConstructor
@Getter
@Setter
public class People {
    private final Long id;
    private final String name;
    private int age;
    private List<String> hobbies;

}
