package com.estsoft.springdemoproject.controller;

import com.estsoft.springdemoproject.repository.StudentJdbcRepository;
import lombok.AllArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@AllArgsConstructor
public class StudentController {
    private final StudentJdbcRepository studentJdbcRepository;

    @GetMapping("/student/name/list")
    public List<String> getListOfStudentName() {
        return studentJdbcRepository.selectStudentNameList();
    }

    @GetMapping("/student/name")
    public Map<String, Object> getStudentName(@RequestParam String name, @RequestParam int age) {
        return studentJdbcRepository.selectStudentName(name, age);
    }
}
