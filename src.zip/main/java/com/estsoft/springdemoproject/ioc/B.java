package com.estsoft.springdemoproject.ioc;

public class B {
}
