package com.estsoft.springdemoproject.ioc;

public interface Inter {
    void method();
}
