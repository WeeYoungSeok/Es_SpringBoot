package com.estsoft.springdemoproject.ioc;

public class A {
    Inter inter;

    public A(Inter inter) {
        this.inter = inter;
    }

    public void method2() {
        inter.method();
    }
}
