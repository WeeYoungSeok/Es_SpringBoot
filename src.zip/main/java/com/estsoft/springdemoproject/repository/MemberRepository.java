package com.estsoft.springdemoproject.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
// 어떤 엔티티, pk의 타입 (JpaRepository)
public interface MemberRepository extends JpaRepository<Member, Long> {
}
