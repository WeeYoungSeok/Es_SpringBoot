package com.estsoft.springdemoproject.repository;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Getter
@Setter
public class Student {
    private long id;
    private String name;
    private int age;
    private String desc;
    private Date createAt;

    public Student() {

    }

    public Student(long id, String name, int age, String desc, java.sql.Date createAt) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.desc = desc;
        this.createAt = createAt;
    }
}
