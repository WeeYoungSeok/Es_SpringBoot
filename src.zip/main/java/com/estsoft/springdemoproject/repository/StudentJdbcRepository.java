package com.estsoft.springdemoproject.repository;

import lombok.AllArgsConstructor;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository
@AllArgsConstructor
public class StudentJdbcRepository {

    private final JdbcTemplate jdbcTemplate;
    private final NamedParameterJdbcTemplate namedParameterJdbcTemplate;

    public List<String> selectStudentNameList() {
        return jdbcTemplate.queryForList("select name from student", String.class);
    }

    public Map<String, Object> selectStudentName(String name, Integer age) {
        return jdbcTemplate.queryForMap("select name from student where name =? and age = ?", name, age);
    }
}
