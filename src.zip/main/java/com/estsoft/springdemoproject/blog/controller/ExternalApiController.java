package com.estsoft.springdemoproject.blog.controller;

import com.estsoft.springdemoproject.blog.domain.AddArticleRequest;
import com.estsoft.springdemoproject.blog.domain.Article;
import com.estsoft.springdemoproject.blog.domain.Content;
import com.estsoft.springdemoproject.blog.service.BlogService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.lang.reflect.ParameterizedType;
import java.util.List;

@Slf4j
@RestController
public class ExternalApiController {

    private final BlogService blogService;

    public ExternalApiController(BlogService blogService) {
        this.blogService = blogService;
    }

    @GetMapping("/api/external")
    public String callApi() {
        RestTemplate restTemplate = new RestTemplate();

        String url = "https://jsonplaceholder.typicode.com/posts";

        // 바로 exchange로 json -> Object 역직렬화 하기
        // 마지막 인자가 역직렬화 타입 (Class 생성해서 받기)
        ResponseEntity<List<Content>> contentList = restTemplate.exchange(
                url,
                HttpMethod.GET,
                null, new ParameterizedTypeReference<List<Content>>() {}
        );

        // 객체 저장 (Article)
        contentList.getBody().forEach(
                content -> blogService.saveArticle(AddArticleRequest.builder()
                        .title(content.getTitle())
                        .content(content.getBody())
                        .build())
        );


        // String으로 받기
//        ResponseEntity<String> json = restTemplate.getForEntity(
//                "https://jsonplaceholder.typicode.com/posts", String.class);

//        log.info("StatusCode : {}", json.getStatusCode());
//        log.info(json.getBody());



        return "OK";
    }
}
