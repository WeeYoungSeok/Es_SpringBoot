package com.estsoft.springdemoproject.blog.controller;

import com.estsoft.springdemoproject.blog.domain.AddArticleRequest;
import com.estsoft.springdemoproject.blog.domain.Article;
import com.estsoft.springdemoproject.blog.domain.ArticleResponse;
import com.estsoft.springdemoproject.blog.domain.UpdateArticleRequest;
import com.estsoft.springdemoproject.blog.service.BlogService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
@Slf4j
@RequestMapping("/api")
public class BlogController {

    private final BlogService blogService;

    @PostMapping("/article")
    public ResponseEntity<Article> writeArticle(@RequestBody AddArticleRequest addArticleRequest) {
        log.info("{}, {}", addArticleRequest.getTitle(), addArticleRequest.getContent());

        return ResponseEntity.status(HttpStatus.CREATED)
                .body(blogService.saveArticle(addArticleRequest));
    }

    @GetMapping("/article")
    public ResponseEntity<List<ArticleResponse>> getArticle() {
        return ResponseEntity.status(HttpStatus.OK)
                .body(blogService.findAlArticles().stream()
                        .map(Article::toResponse)
                        .toList());
    }

    @GetMapping("/article/{id}")
    public ResponseEntity<ArticleResponse> getArticleById(@PathVariable Long id) {
        return ResponseEntity.status(HttpStatus.OK)
                .body(blogService.findArticleById(id).toResponse());
    }

    @DeleteMapping("/article/{id}")
    public ResponseEntity<Void> deleteArticleById(@PathVariable Long id) {
        blogService.deleteArticleById(id);
        return ResponseEntity.status(HttpStatus.OK).build();
    }

    @PutMapping("/article/{id}")
    public ResponseEntity<Article> updateArticleById(@PathVariable Long id, @RequestBody UpdateArticleRequest updateArticleRequest) {
        return ResponseEntity.status(HttpStatus.OK).body(blogService.updateArticle(id, updateArticleRequest));
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<String> handlerIllegalArgumentException(IllegalArgumentException e) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
    }
}
