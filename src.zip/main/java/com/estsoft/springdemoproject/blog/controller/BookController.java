package com.estsoft.springdemoproject.blog.controller;

import com.estsoft.springdemoproject.blog.domain.Book;
import com.estsoft.springdemoproject.blog.domain.BookDto;
import com.estsoft.springdemoproject.blog.service.BookService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/books")
@RequiredArgsConstructor
public class BookController {

    private final BookService bookService;

    @GetMapping
    public String showAll(Model model) {
        List<BookDto> list = bookService.getAllBooks()
                .stream()
                .map(BookDto::new)
                .toList();
        model.addAttribute("bookList", list);
        return "bookManagement";
    }

    @GetMapping("/{id}")
    public String showOne(@PathVariable String id, Model model) {
        BookDto bookDto = new BookDto(bookService.findBookById(id));
        model.addAttribute("book", bookDto);
        return "bookDetail";
    }

    @PostMapping
    public String add(@RequestParam String id,
                      @RequestParam String name,
                      @RequestParam String author,
                      Model model) {
        bookService.addBook(Book.builder()
                .id(id)
                .name(name)
                .author(author)
                .build());
        return "redirect:/books";
    }
}
