package com.estsoft.springdemoproject.blog.domain;

import lombok.Getter;

@Getter
public class BookDto {
    private String id;
    private String name;
    private String author;

    public BookDto(Book book) {
        this.id = book.getId();
        this.name = book.getName();
        this.author = book.getAuthor();
    }

    public Book toEntity() {
        return Book.builder()
                .id(this.id)
                .name(this.name)
                .author(this.author)
                .build();
    }
}
