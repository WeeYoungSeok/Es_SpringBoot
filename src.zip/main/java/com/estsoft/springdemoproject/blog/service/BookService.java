package com.estsoft.springdemoproject.blog.service;

import com.estsoft.springdemoproject.blog.domain.Book;
import com.estsoft.springdemoproject.blog.repository.BookRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class BookService {

    private final BookRepository bookRepository;

    public List<Book> getAllBooks() {
        return bookRepository.findAll(Sort.by(Sort.Direction.ASC, "id"));
    }

    public Book findBookById(String id) {
        return bookRepository.findById(id).orElse(new Book());
    }

    public Book addBook(Book book) {
        return bookRepository.save(book);
    }
}
