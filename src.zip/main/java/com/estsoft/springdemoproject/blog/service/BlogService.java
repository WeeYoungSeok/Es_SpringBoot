package com.estsoft.springdemoproject.blog.service;

import com.estsoft.springdemoproject.blog.domain.AddArticleRequest;
import com.estsoft.springdemoproject.blog.domain.Article;
import com.estsoft.springdemoproject.blog.domain.ArticleResponse;
import com.estsoft.springdemoproject.blog.domain.UpdateArticleRequest;
import com.estsoft.springdemoproject.blog.repository.BlogRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
public class BlogService {
    private final BlogRepository blogRepository;

    public BlogService(BlogRepository blogRepository) {
        this.blogRepository = blogRepository;
    }

    // 게시즐 저장
    public Article saveArticle(AddArticleRequest addArticleRequest) {
        return blogRepository.save(addArticleRequest.toEntity());
    }

    // 조회
    public List<Article> findAlArticles() {
        return blogRepository.findAll();
    }

    // 단건 조회
    public Article findArticleById(Long id) {
        return blogRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("없어"));
    }

    // 삭제
    public void deleteArticleById(Long id) {
        blogRepository.deleteById(id);
    }

    // 수정
    @Transactional
    public Article updateArticle(Long id, UpdateArticleRequest updateArticleRequest) {
        findArticleById(id).update(updateArticleRequest.getTitle(), updateArticleRequest.getContent());
        return blogRepository.save(findArticleById(id));
    }
}
