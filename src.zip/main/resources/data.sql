INSERT INTO article (title, content, create_at, update_at) VALUES ('제목1', '내용1', now(), now());
INSERT INTO article (title, content, create_at, update_at) VALUES ('제목2', '내용2', now(), now());
INSERT INTO article (title, content, create_at, update_at) VALUES ('제목3', '내용3', now(), now());


INSERT INTO book (id, name, author) VALUES ('첫번째', '스프링 JPA', '김영한');
INSERT INTO book (id, name, author) VALUES ('두번째', '하이루', '위영석');

